import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import MainLayout from './components/Layout/MainLayout.jsx'
import FetchOld from './pages/FetchOld.jsx'
import FetchRq from './pages/FetchRq.jsx'
import Home from './pages/Home.jsx'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { ReactQueryDevtools } from '@tanstack/react-query-devtools'
import FetchIndv from './components/Layout/UI/FetchIndv.jsx'
import Infinite from './pages/Infinite.jsx'


  const queryClient = new QueryClient()       // queryClient


// router
const router = createBrowserRouter([
  {
    path : "/",
    element : <MainLayout />,
    children : [
      {
        path : '/',
        element : <Home />
      },
      {
        path : '/fetchold',
        element : <FetchOld />
      },
      {
        path : '/fetchrq',
        element : <FetchRq />
      },
      {
        path : '/fetchrq/:id',
        element : <FetchIndv />
      },
      {
        path : '/infinite',
        element : <Infinite />
      },
    ]
  }
])

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <RouterProvider router={router}/>
      <ReactQueryDevtools initialIsOpen={false}/>
    </QueryClientProvider>
  </StrictMode>,
)
