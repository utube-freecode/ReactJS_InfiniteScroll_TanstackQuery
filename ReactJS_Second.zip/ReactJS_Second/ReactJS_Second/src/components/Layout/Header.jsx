import { NavLink } from "react-router-dom"



const Header = () => {
    return(
   
   <header>
        <div>
            <NavLink to={'/'}>Home</NavLink>
        </div>
        <div>
            <NavLink to={'/fetchold'}>Fetch Old</NavLink>
        </div>
        <div>
            <NavLink to={'/fetchrq'}>Fetch React Query</NavLink>
        </div>
        <div>
            <NavLink to={'/infinite'}>Infinite Scroll</NavLink>
        </div>
   </header>
    )
}


export default Header