import { NavLink, useLocation, useParams } from "react-router-dom";
import { fetchPostIndv } from "../../../API/api";
import { useQuery } from "@tanstack/react-query";



const FetchIndv = () => {

    const {id} = useParams()

        const getPostDataInc = async(id) => {
                try {
                    const response = await fetchPostIndv(id);
        
                    console.log(response, "response")
    
                    return response.status === 200 ? response.data : []
                } catch (error) {
                    console.log(error, "error")
                }
        }
    

        // useQuery
        const {data, isError, isPending, error} = useQuery({
            queryKey : ['postIndv', {id}],                            
            queryFn : () => getPostDataInc(id),                      
        })

    return(
    <div>
            <h1> Fetch Individual</h1>

            <p>id : {data?.id}</p>

            <p>{data?.title}</p>
            <p>{data?.body}</p>

            <NavLink to={'/fetchrq'}>Back</NavLink>
    </div>
    )
}


export default FetchIndv