


const Footer = () => {
    return(
    <footer>
        <p>@copyright</p>
    </footer>
    )
}


export default Footer