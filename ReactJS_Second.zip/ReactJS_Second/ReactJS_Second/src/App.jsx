import './App.css'

function App() {

  return (
    <>
      <h1>React Query</h1>
    </>
  )
}

export default App
