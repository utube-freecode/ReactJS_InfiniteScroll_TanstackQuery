import { keepPreviousData, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { deletePost, fetchPosts, updatePost } from "../API/api";
import { useState } from "react";
import { NavLink } from "react-router-dom";



const FetchRq = () => {

    const [start, setStart] = useState(1)
    const [limit, setLimit] = useState(3)

    const queryClient = useQueryClient()            // useQueryClient


        // getPostData
        const getPostData = async(start, limit) => {
    
                const response = await fetchPosts(start, limit);
    
                console.log(response, "response")

                return response.status === 200 ? response.data : []
        }

        // deletePostbyId
        const deletePostbyId = async(id) => {
    
            const response = await deletePost(id);

            console.log(response, "response")

            return response.status === 200 ? response.data : []
        }

         // updatePostbyId
         const updatePostbyId = async(id) => {
    
            const response = await updatePost(id);

            console.log(response, "response")

            return response.status === 200 ? response.data : []
        }

    

        // useQuery
        const {data, isError, isPending, error} = useQuery({
            queryKey : ['post', {start, limit}],                            // similar to useState
            queryFn : () => getPostData(start, limit),                      // similar to useEffect
            //gcTime : 1000,                                                // Garbage collection time
            //staleTime : 5000,                                               // Stale means data is old and not fresh. So, if we define staleTime means data is fresh for 5secs, after that api request will be sent.
            //refetchInterval : 2000,                                          // refetch Data after every 2secs
            //refetchIntervalInBackground : true                                // refetch while in background
            placeholderData : keepPreviousData,                                 // for Pagination
        })


        // delete useMutation
        const deleteMutation = useMutation({
            mutationFn : (id) => deletePostbyId(id),
            onSuccess : (data, id) => {
                queryClient.setQueryData(['post', {start, limit}], (item) => {
                    return item?.filter((post) => post?.id !== id)
                })
            }
        })

        // update useMutation
        const updateMutation = useMutation({
            mutationFn : (id) => updatePostbyId(id),
            onSuccess : (apiData, id) => {
                queryClient.setQueryData(['post', {start, limit}], (postData) => {
                    return postData?.map((curpost) => 
                        curpost?.id === id ? {...curpost, title : apiData?.title} : curpost
                )})
            }
        })

    return(
    <>
        <h1>FetchRq</h1>

        <input type="number" placeholder="start" name="start" onChange={(e) => setStart(e.target.value)}/>

        <input type="number" placeholder="limit" name="limit" onChange={(e) => setLimit(e.target.value)}/>

        {isPending && (
            <p>Loading...</p>
        )}

        {isError && (
            <p>{error?.message || "Something went wrong"}</p>
        )}

        {data && (
            <ul>
                {data?.map((item) => (
                    <li key={item?.id}>
                        <NavLink to={`/fetchrq/${item?.id}`}>
                            <p>{item?.id}</p>
                            <p>{item?.title}</p>
                            <p>{item?.body}</p>
                        </NavLink>
                        <button onClick={() => updateMutation.mutate(item?.id)} type="button">Update</button>
                        <button onClick={() => deleteMutation.mutate(item?.id)} type="button">Delete</button>
                    </li>
                ))}
            </ul>
        )}
    </>
    )
}


export default FetchRq