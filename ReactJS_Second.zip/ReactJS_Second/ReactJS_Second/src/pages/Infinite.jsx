import { keepPreviousData, useInfiniteQuery, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { deletePost, fetchPosts, infinitePosts, infiniteUsers, updatePost } from "../API/api";
import { useEffect, useState } from "react";
import { NavLink } from "react-router-dom";
import { useInView } from "react-intersection-observer";



const Infinite = () => {

    const [start, setStart] = useState(1)
    const [limit, setLimit] = useState(3)

    const queryClient = useQueryClient()            // useQueryClient


        // getUsers
        const getUsers = async(pageParam = 0) => {
                console.log(pageParam, "pageParam")
    
                const response = await infinitePosts(pageParam);
    
                console.log(response, "response")

                return response.status === 200 ? response.data : []
        }

        // deletePostbyId
        const deletePostbyId = async(id) => {
    
            const response = await deletePost(id);

            console.log(response, "response")

            return response.status === 200 ? response.data : []
        }

         // updatePostbyId
         const updatePostbyId = async(id) => {
    
            const response = await updatePost(id);

            console.log(response, "response")

            return response.status === 200 ? response.data : []
        }


        // delete useMutation
        const deleteMutation = useMutation({
            mutationFn : (id) => deletePostbyId(id),
            onSuccess : (data, id) => {
                queryClient.setQueryData(['post', {start, limit}], (item) => {
                    return item?.filter((post) => post?.id !== id)
                })
            }
        })

        // update useMutation
        const updateMutation = useMutation({
            mutationFn : (id) => updatePostbyId(id),
            onSuccess : (apiData, id) => {
                queryClient.setQueryData(['post', {start, limit}], (postData) => {
                    return postData?.map((curpost) => 
                        curpost?.id === id ? {...curpost, title : apiData?.title} : curpost
                )})
            }
        })

        // useInfiniteQuery
        const {data, isError, isPending, error, hasNextPage, fetchNextPage, isFetchNextPageError, isFetchingNextPage} = useInfiniteQuery({
            queryKey : ['users'],
            queryFn : ({pageParam = 0}) => getUsers(pageParam),
            getNextPageParam : (lastPage, allPages) => {
                console.log(lastPage, "lastPage")
                console.log(allPages, "allPages")

                // Get the next page number correctly
                return lastPage.length > 0 ? allPages.length : undefined; // Use length directly
            }
        })

        console.log(data, "data")
        console.log(hasNextPage, "hasNextPage")

        const {ref, inView} = useInView({
            threshold : 1,
        })

        console.log(inView, "inView")


        //handleScroll
        const handleScroll = () => {
            const bottom = window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 10

            if(bottom && hasNextPage){
                fetchNextPage()
            }

        }


        // useEffect
        useEffect(() => {
            window.addEventListener('scroll', handleScroll);

            return () => window.removeEventListener('scroll', handleScroll)

            // if(inView && hasNextPage){
            //     fetchNextPage()
            // }
        }, [hasNextPage])


    return(
    <>
        <h1>Infinite</h1>

        {isPending && (
            <p>Loading...</p>
        )}

        {isError && (
            <p>{error?.message || "Something went wrong"}</p>
        )}

        {data && data?.pages?.map((page, index) => (
            <ul key={index}>
                {page?.map((user) => (
                    <li key={user?.id}>
                        <p>{user?.id}</p>
                        {/* <img 
                            src={user?.avatar_url}
                            alt={user?.login}
                            width={50}
                            height={50}
                        /> */}
                    </li>
                ))}
            </ul>
        ))}

        {/* <div ref={ref}>Scroll down to load more</div> */}

        {isFetchingNextPage && <p>Loading more...</p>}

    </>
    )
}


export default Infinite