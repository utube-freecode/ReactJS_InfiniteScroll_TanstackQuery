import { useEffect, useState } from "react"
import { fetchPosts } from "../API/api"



const FetchOld = () => {

    const [post, setPost] = useState([])
    // const [isLoading, setIsLoading] = useState()
    // const [error, setError] = useState()

    const getPostData = async() => {
        try {

            const response = await fetchPosts(1, 3);

            console.log(response, "response")

            response?.status === 200 ? setPost(response?.data) : setPost([])
            
        } catch (error) {
            console.log(error, "error")
        }
    }

    useEffect(() => {
        getPostData()       // Calling Function
    },[])

    return(
    <>
        <h1>FetchOld</h1>

        <ul>
            {post.length > 0 && post?.map((item) => (
                <li key={item?.id}>
                    <p>{item?.title}</p>
                    <p>{item?.body}</p>
                </li>
            ))}
        </ul>
    </>
    )
}


export default FetchOld