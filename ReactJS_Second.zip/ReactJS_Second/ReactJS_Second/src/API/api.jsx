import axios from "axios";


const api = axios.create({
    baseURL : "https://jsonplaceholder.typicode.com"
})


// to fetch data
export const fetchPosts = (start, limit) => {
    return api.get(`/posts?_start=${start}&_limit=${limit}`)
}

// to fetch individual data
export const fetchPostIndv = (id) => {
    return api.get(`/posts/${id}`)
}

// to delete post
export const deletePost = (id) => {
    return api.delete(`/posts/${id}`)
}

// to update post
export const updatePost = (id) => {
    return api.patch(`/posts/${id}`, {title : "i have updated"})
}

// to infinite scroll
export const infiniteUsers = (pageParam) => {
    return axios.get(`https://api.github.com/users?since=${pageParam}&per_page=10`)
}

// to infinite scroll
export const infinitePosts = (pageParam) => {
    return api.get(`/posts?_start=${pageParam}&_limit=10`)
}